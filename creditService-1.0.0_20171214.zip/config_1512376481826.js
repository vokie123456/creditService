;(function (win) {
    win.config = {

    }
})(window);